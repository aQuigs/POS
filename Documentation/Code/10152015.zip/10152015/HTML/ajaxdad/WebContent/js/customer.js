
$(document).ready(function() {
	getRestaurants();
});
